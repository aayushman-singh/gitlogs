import { Clock, TrendingUp, Zap } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const benefits = [
  {
    icon: Clock,
    title: "Save Hours Weekly",
    description:
      "Stop context-switching between coding and posting. gitlogs handles your social presence automatically.",
    image:
      "https://placehold.co/600x400?text=Developer+focused+on+coding+with+dual+monitors+showing+clean+IDE+interface+dark+theme",
  },
  {
    icon: TrendingUp,
    title: "Boost Visibility",
    description:
      "Every commit becomes a post. Build your developer brand and showcase your consistency without lifting a finger.",
    image:
      "https://placehold.co/600x400?text=Analytics+dashboard+showing+upward+trending+graphs+and+engagement+metrics+modern+dark+UI",
  },
  {
    icon: Zap,
    title: "Zero Effort Required",
    description:
      "Connect once, forget forever. Your commits automatically transform into engaging posts that attract opportunities.",
    image:
      "https://placehold.co/600x400?text=Automated+workflow+visualization+with+GitHub+and+X+logos+connected+by+smooth+gradient+lines",
  },
]

export function Benefits() {
  return (
    <section className="py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-3xl md:text-5xl font-bold text-balance">Why developers choose gitlogs</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            Built to solve the real problem: staying visible while staying productive
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {benefits.map((benefit) => {
            const Icon = benefit.icon
            return (
              <Card
                key={benefit.title}
                className="border-border bg-card overflow-hidden hover:border-primary/50 transition-colors"
              >
                <div className="aspect-video bg-muted overflow-hidden">
                  <img
                    src={benefit.image || "/placeholder.svg"}
                    alt={benefit.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold">{benefit.title}</h3>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
