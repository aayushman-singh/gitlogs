import { Button } from "@/components/ui/button"
import { GitBranch, Github, Twitter, Code2 } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border">
      {/* CTA Section */}
      <section className="py-24 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold text-balance">Ready to automate your presence?</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            Join developers who code more and post less
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <Button size="lg" className="text-lg px-8 py-6 h-auto">
              <GitBranch className="w-5 h-5 mr-2" />
              Get Started Free
            </Button>
          </div>
        </div>
      </section>

      {/* Footer Links */}
      <div className="border-t border-border px-4 py-8">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 text-xl font-bold">
            <Code2 className="w-6 h-6" />
            <span>gitlogs</span>
          </div>

          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">
              Privacy
            </a>
            <a href="#" className="hover:text-foreground transition-colors">
              Terms
            </a>
            <a href="#" className="hover:text-foreground transition-colors">
              Docs
            </a>
            <a href="#" className="hover:text-foreground transition-colors flex items-center gap-2">
              <Github className="w-4 h-4" />
              GitHub
            </a>
            <a href="#" className="hover:text-foreground transition-colors flex items-center gap-2">
              <Twitter className="w-4 h-4" />X
            </a>
          </div>

          <p className="text-sm text-muted-foreground">© 2025 gitlogs. For developers, by developers.</p>
        </div>
      </div>
    </footer>
  )
}
