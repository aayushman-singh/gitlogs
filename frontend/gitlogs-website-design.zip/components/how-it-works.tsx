import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Check } from "lucide-react"

const steps = [
  {
    number: "01",
    title: "Connect GitHub",
    description: "Authorize gitlogs with one click. We only need read access to your public commits.",
    features: ["Secure OAuth", "Public repos only", "Revoke anytime"],
  },
  {
    number: "02",
    title: "Link X Account",
    description: "Connect your X account so we can post on your behalf when you push code.",
    features: ["Full control", "Custom templates", "Edit before post"],
  },
  {
    number: "03",
    title: "Code Normally",
    description: "That's it. Keep pushing commits and building. gitlogs handles the rest automatically.",
    features: ["Auto-detect commits", "Smart formatting", "Perfect timing"],
  },
]

export function HowItWorks() {
  return (
    <section className="py-24 px-4 bg-card/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-3xl md:text-5xl font-bold text-balance">Get started in 2 minutes</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            Simple setup, powerful automation
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connection lines for desktop */}
          <div className="hidden md:block absolute top-24 left-[16.66%] right-[16.66%] h-0.5 bg-border" />

          {steps.map((step, index) => (
            <div key={step.number} className="relative">
              <Card className="border-border bg-card h-full">
                <CardContent className="p-8 space-y-6">
                  <div className="flex items-start justify-between">
                    <div className="text-6xl font-bold text-primary/20">{step.number}</div>
                    {index < steps.length - 1 && (
                      <ArrowRight className="hidden md:block w-6 h-6 text-muted-foreground mt-4" />
                    )}
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-2xl font-semibold">{step.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                  </div>

                  <ul className="space-y-2 pt-4">
                    {step.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Check className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <img
            src="https://placehold.co/1200x600?text=Clean+dashboard+interface+showing+connected+GitHub+and+X+accounts+with+recent+automated+posts+timeline+dark+modern+UI"
            alt="gitlogs dashboard showing GitHub commits automatically posted to X with engagement metrics and customization options"
            className="rounded-lg border border-border mx-auto max-w-5xl w-full"
          />
          <p className="text-sm text-muted-foreground mt-4">Your dashboard shows all automated posts and engagement</p>
        </div>
      </div>
    </section>
  )
}
