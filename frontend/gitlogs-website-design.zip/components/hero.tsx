import { Button } from "@/components/ui/button"
import { Code2, GitBranch } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 py-20">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background to-card" />

      <div className="relative max-w-5xl mx-auto text-center space-y-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-border bg-card/50 text-sm text-muted-foreground mb-6">
          <Code2 className="w-4 h-4" />
          <span>For developers, by developers</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-balance leading-tight">
          Code more.
          <br />
          Post less.
        </h1>

        <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto text-balance leading-relaxed">
          gitlogs takes your GitHub commits and posts on X on your behalf. Spend your time coding, not yapping.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
          <Button size="lg" className="text-lg px-8 py-6 h-auto">
            <GitBranch className="w-5 h-5 mr-2" />
            Sign Up with GitHub
          </Button>
          <Button size="lg" variant="outline" className="text-lg px-8 py-6 h-auto bg-transparent">
            Login
          </Button>
        </div>

        <p className="text-sm text-muted-foreground pt-4">No credit card required • 2 minute setup</p>
      </div>
    </section>
  )
}
